library(testthat)
library(tidyHeatmap)

test_check("tidyHeatmap")
