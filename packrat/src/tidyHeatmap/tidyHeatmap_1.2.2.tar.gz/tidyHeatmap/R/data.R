#' Example data set N52
#' 
#'
#'
"N52"

#' Example data set Pasilla
#' 
#'
#'
"pasilla"