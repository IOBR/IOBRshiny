# method which return text works - snapshot

    Code
      pb$data
    Output
      [[1]]
         ymin lower middle upper ymax outliers notchupper notchlower  x flipped_aes
      1   1.8 1.800   2.80 2.800 2.80            3.326667   2.273333  1       FALSE
      2   3.1 4.400   5.70 5.700 6.50      2.4   6.476339   4.923661  2       FALSE
      3   2.4 3.675   3.90 5.200 5.90            4.502375   3.297625  3       FALSE
      4   3.8 4.000   4.60 4.600 5.40            4.844773   4.355227  4       FALSE
      5   1.6 1.600   1.60 1.600 1.60            1.600000   1.600000  5       FALSE
      6   2.0 2.100   2.40 2.475 2.50            2.641887   2.158113  6       FALSE
      7   4.0 4.175   4.35 4.525 4.70            4.741030   3.958970  7       FALSE
      8   4.0 4.150   4.30 4.450 4.60            4.635169   3.964831  8       FALSE
      9   5.4 5.400   5.40 5.400 5.40            5.400000   5.400000  9       FALSE
      10  4.0 4.250   4.50 4.750 5.00            5.058614   3.941386 10       FALSE
      11  2.4 2.550   3.00 3.225 3.30            3.435397   2.564603 11       FALSE
      12  3.1 3.450   3.80 3.800 3.80            4.119275   3.480725 12       FALSE
      13  2.2 2.275   2.50 2.500 2.50            2.645132   2.354868 13       FALSE
      14  1.8 2.200   2.70 3.100 3.40      4.7   3.017969   2.382031 14       FALSE
      15  1.8 1.900   2.00 2.800 2.80            2.355500   1.644500 15       FALSE
      16  2.0 2.000   3.10 3.100 4.20            3.679333   2.520667  1       FALSE
      17  3.5 4.875   5.30 6.050 7.00      2.4   5.835925   4.764075  2       FALSE
      18  3.3 3.800   4.70 4.700 5.70            5.010306   4.389694  3       FALSE
      19  4.0 4.150   4.60 5.200 5.40            5.124622   4.075378  4       FALSE
      20  1.8 1.800   1.80 1.850 1.85        2   1.839500   1.760500  5       FALSE
      21  2.0 2.300   2.55 2.700 3.30            2.773446   2.326554  6       FALSE
      22  3.0 3.950   4.70 5.450 6.10            5.667548   3.732452  7       FALSE
      23  4.2 4.250   4.30 4.350 4.40            4.411723   4.188277  8       FALSE
      24  5.4 5.400   5.40 5.400 5.40            5.400000   5.400000  9       FALSE
      25  4.0 4.150   4.30 4.450 4.60            4.635169   3.964831 10       FALSE
      26  2.5 3.000   3.50 3.750 4.00      5.6   3.947888   3.052112 11       FALSE
      27  3.8 4.175   4.55 4.925 5.30            5.387922   3.712078 12       FALSE
      28  2.5 2.500   2.50 2.500 2.50            2.500000   2.500000 13       FALSE
      29  1.8 2.400   3.00 4.000 5.70            3.675636   2.324364 14       FALSE
      30  2.0 2.000   2.00 2.500 2.50      3.6   2.238194   1.761806 15       FALSE
         PANEL group   y ymin_final ymax_final   xmin   xmax xid newx new_width
      1      1     1  NA        1.8        2.8  0.625  1.375   1    1      0.75
      2      1     2  NA        2.4        6.5  1.625  2.375   2    2      0.75
      3      1     3  NA        2.4        5.9  2.625  3.375   3    3      0.75
      4      1     4  NA        3.8        5.4  3.625  4.375   4    4      0.75
      5      1     5 1.6        1.6        1.6  4.625  5.375   5    5      0.75
      6      1     6  NA        2.0        2.5  5.625  6.375   6    6      0.75
      7      1     7  NA        4.0        4.7  6.625  7.375   7    7      0.75
      8      1     8  NA        4.0        4.6  7.625  8.375   8    8      0.75
      9      1     9 5.4        5.4        5.4  8.625  9.375   9    9      0.75
      10     1    10  NA        4.0        5.0  9.625 10.375  10   10      0.75
      11     1    11  NA        2.4        3.3 10.625 11.375  11   11      0.75
      12     1    12  NA        3.1        3.8 11.625 12.375  12   12      0.75
      13     1    13  NA        2.2        2.5 12.625 13.375  13   13      0.75
      14     1    14  NA        1.8        4.7 13.625 14.375  14   14      0.75
      15     1    15  NA        1.8        2.8 14.625 15.375  15   15      0.75
      16     2     1  NA        2.0        4.2  0.625  1.375   1    1      0.75
      17     2     2  NA        2.4        7.0  1.625  2.375   2    2      0.75
      18     2     3  NA        3.3        5.7  2.625  3.375   3    3      0.75
      19     2     4  NA        4.0        5.4  3.625  4.375   4    4      0.75
      20     2     5  NA        1.8        2.0  4.625  5.375   5    5      0.75
      21     2     6  NA        2.0        3.3  5.625  6.375   6    6      0.75
      22     2     7  NA        3.0        6.1  6.625  7.375   7    7      0.75
      23     2     8  NA        4.2        4.4  7.625  8.375   8    8      0.75
      24     2     9 5.4        5.4        5.4  8.625  9.375   9    9      0.75
      25     2    10  NA        4.0        4.6  9.625 10.375  10   10      0.75
      26     2    11  NA        2.5        5.6 10.625 11.375  11   11      0.75
      27     2    12  NA        3.8        5.3 11.625 12.375  12   12      0.75
      28     2    13 2.5        2.5        2.5 12.625 13.375  13   13      0.75
      29     2    14  NA        1.8        5.7 13.625 14.375  14   14      0.75
      30     2    15  NA        2.0        3.6 14.625 15.375  15   15      0.75
         weight colour  fill size alpha shape linetype
      1       1 grey20 white  0.5    NA    19    solid
      2       1 grey20 white  0.5    NA    19    solid
      3       1 grey20 white  0.5    NA    19    solid
      4       1 grey20 white  0.5    NA    19    solid
      5       1 grey20 white  0.5    NA    19    solid
      6       1 grey20 white  0.5    NA    19    solid
      7       1 grey20 white  0.5    NA    19    solid
      8       1 grey20 white  0.5    NA    19    solid
      9       1 grey20 white  0.5    NA    19    solid
      10      1 grey20 white  0.5    NA    19    solid
      11      1 grey20 white  0.5    NA    19    solid
      12      1 grey20 white  0.5    NA    19    solid
      13      1 grey20 white  0.5    NA    19    solid
      14      1 grey20 white  0.5    NA    19    solid
      15      1 grey20 white  0.5    NA    19    solid
      16      1 grey20 white  0.5    NA    19    solid
      17      1 grey20 white  0.5    NA    19    solid
      18      1 grey20 white  0.5    NA    19    solid
      19      1 grey20 white  0.5    NA    19    solid
      20      1 grey20 white  0.5    NA    19    solid
      21      1 grey20 white  0.5    NA    19    solid
      22      1 grey20 white  0.5    NA    19    solid
      23      1 grey20 white  0.5    NA    19    solid
      24      1 grey20 white  0.5    NA    19    solid
      25      1 grey20 white  0.5    NA    19    solid
      26      1 grey20 white  0.5    NA    19    solid
      27      1 grey20 white  0.5    NA    19    solid
      28      1 grey20 white  0.5    NA    19    solid
      29      1 grey20 white  0.5    NA    19    solid
      30      1 grey20 white  0.5    NA    19    solid
      
      [[2]]
          x xend     y  yend annotation            group PANEL shape colour textsize
      1   1    1 6.549 6.598     1.9***      audi-ford-1     1    19  black     3.88
      2   1    4 6.598 6.598     1.9***      audi-ford-1     1    19  black     3.88
      3   4    4 6.598 6.549     1.9***      audi-ford-1     1    19  black     3.88
      4   6    6 6.549 6.598       1.3* hyundai-nissan-2     1    19  black     3.88
      5   6   11 6.598 6.598       1.3* hyundai-nissan-2     1    19  black     3.88
      6  11   11 6.598 6.549       1.3* hyundai-nissan-2     1    19  black     3.88
      7   1    1 7.052 7.104     1.7***      audi-ford-1     2    19  black     3.88
      8   1    4 7.104 7.104     1.7***      audi-ford-1     2    19  black     3.88
      9   4    4 7.104 7.052     1.7***      audi-ford-1     2    19  black     3.88
      10  6    6 7.052 7.104       1.4* hyundai-nissan-2     2    19  black     3.88
      11  6   11 7.104 7.104       1.4* hyundai-nissan-2     2    19  black     3.88
      12 11   11 7.104 7.052       1.4* hyundai-nissan-2     2    19  black     3.88
         angle hjust vjust alpha family fontface lineheight linetype size
      1      0   0.5     0    NA               1        1.2        1  0.5
      2      0   0.5     0    NA               1        1.2        1  0.5
      3      0   0.5     0    NA               1        1.2        1  0.5
      4      0   0.5     0    NA               1        1.2        1  0.5
      5      0   0.5     0    NA               1        1.2        1  0.5
      6      0   0.5     0    NA               1        1.2        1  0.5
      7      0   0.5     0    NA               1        1.2        1  0.5
      8      0   0.5     0    NA               1        1.2        1  0.5
      9      0   0.5     0    NA               1        1.2        1  0.5
      10     0   0.5     0    NA               1        1.2        1  0.5
      11     0   0.5     0    NA               1        1.2        1  0.5
      12     0   0.5     0    NA               1        1.2        1  0.5
      

# identical annotations are plotted separetly - snapshot

    Code
      pb$data
    Output
      [[1]]
          fill     x y PANEL group flipped_aes ymin ymax xmin xmax colour size
      1 grey80 0.875 3     1     1       FALSE    0    3 0.75 1.00     NA  0.5
      2 grey20 1.125 5     1     3       FALSE    0    5 1.00 1.25     NA  0.5
      3 grey80 1.875 7     1     2       FALSE    0    7 1.75 2.00     NA  0.5
      4 grey20 2.125 8     1     4       FALSE    0    8 2.00 2.25     NA  0.5
        linetype alpha
      1        1    NA
      2        1    NA
      3        1    NA
      4        1    NA
      
      [[2]]
        x xend     y  yend annotation   group PANEL shape colour textsize angle hjust
      1 1    1 9.575 9.575        *** S1-S2-1     1    19  black     3.88     0   0.5
      2 1    2 9.575 9.575        *** S1-S2-1     1    19  black     3.88     0   0.5
      3 2    2 9.575 9.575        *** S1-S2-1     1    19  black     3.88     0   0.5
        vjust alpha family fontface lineheight linetype size
      1   0.4    NA               1        1.2        1  0.5
      2   0.4    NA               1        1.2        1  0.5
      3   0.4    NA               1        1.2        1  0.5
      
      [[3]]
            x  xend   y yend annotation group PANEL shape colour textsize angle hjust
      1 0.875 1.125 5.8  5.8         **     1     1    19  black     3.88     0   0.5
      2 1.875 2.125 8.5  8.5         **     2     1    19  black     3.88     0   0.5
        vjust alpha family fontface lineheight linetype size
      1     0    NA               1        1.2        1  0.5
      2     0    NA               1        1.2        1  0.5
      

