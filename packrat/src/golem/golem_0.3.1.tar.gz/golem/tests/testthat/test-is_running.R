test_that("is_running", {
  expect_false(is_running())
})
